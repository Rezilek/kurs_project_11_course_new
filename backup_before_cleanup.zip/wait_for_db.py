import os
import sys
import time
import logging
from pathlib import Path

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)


def load_env():
    """Load environment variables from .env file"""
    env_path = Path(__file__).parent / '.env'
    if env_path.exists():
        logger.info(f"Loading environment from {env_path}")
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    os.environ[key.strip()] = value.strip().strip('"\'')
    else:
        logger.warning(f".env file not found at {env_path}")


def wait_for_postgres():
    """Wait for PostgreSQL using psycopg2"""
    load_env()

    # Получаем параметры из переменных окружения
    db_host = os.getenv('POSTGRES_HOST', 'db')
    db_port = os.getenv('POSTGRES_PORT', '5432')
    db_name = os.getenv('POSTGRES_DB', 'kurs_project')
    db_user = os.getenv('POSTGRES_USER', 'kurs_user')
    db_password = os.getenv('POSTGRES_PASSWORD', 'kurs_password')

    max_retries = 30
    retry_delay = 2

    logger.info(f"Waiting for PostgreSQL at {db_host}:{db_port} (database: {db_name}, user: {db_user})")

    for attempt in range(1, max_retries + 1):
        try:
            import psycopg2
            conn = psycopg2.connect(
                host=db_host,
                port=db_port,
                dbname=db_name,
                user=db_user,
                password=db_password,
                connect_timeout=5
            )
            conn.close()
            logger.info(f"✅ PostgreSQL is ready! (attempt {attempt})")
            return True

        except ImportError:
            logger.error("psycopg2 not installed. Installing...")
            try:
                import subprocess
                subprocess.check_call([sys.executable, "-m", "pip", "install", "psycopg2-binary"])
                import psycopg2
                logger.info("psycopg2 installed successfully")
            except Exception as e:
                logger.error(f"Failed to install psycopg2: {e}")
                return False

        except Exception as e:
            error_msg = str(e).split('\n')[0]  # Берем только первую строку ошибки
            logger.warning(f"Attempt {attempt}/{max_retries}: {error_msg}")

            # Полезные подсказки
            if "connection" in error_msg.lower():
                logger.info("  → Make sure PostgreSQL container is running")
            elif "password" in error_msg.lower() or "authentication" in error_msg.lower():
                logger.info("  → Check database credentials in .env file")
            elif "database" in error_msg.lower() and "does not exist" in error_msg.lower():
                logger.info("  → Database doesn't exist yet, it will be created")

            if attempt < max_retries:
                time.sleep(retry_delay)

    logger.error(f"❌ Failed to connect to PostgreSQL after {max_retries} attempts")
    return False


if __name__ == '__main__':
    try:
        success = wait_for_postgres()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        logger.info("Interrupted by user")
        sys.exit(1)