#!/usr/bin/env python
import sys
import time


def wait_for_db():
    """Simple database wait script for Docker"""
    print("Waiting for database...")

    # Просто ждем некоторое время, так как depends_on уже ждет healthcheck
    # Это дает БД дополнительное время для полной инициализации
    time.sleep(5)
    print("Database should be ready now")
    return True


if __name__ == "__main__":
    try:
        if wait_for_db():
            sys.exit(0)
        else:
            sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)