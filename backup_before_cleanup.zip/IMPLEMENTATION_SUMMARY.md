# Реализация ТЗ: Подписки, Пагинация, Тесты

## 📋 Выполненные задачи

### ✅ Задание 1-2: Модель подписки и поле is_subscribed
- **Модель Subscription** создана в `courses/models.py`
- **Поле is_subscribed** добавлено в `CourseSerializer`
- **Логика работы**: поле вычисляется динамически для текущего пользователя

### ✅ Задание 3: Пагинация
- **Файл paginators.py** создан с тремя классами:
  - `CoursePagination` (5 элементов на страницу)
  - `LessonPagination` (10 элементов на страницу) 
  - `SubscriptionPagination`
- **Интеграция**: подключено через `pagination_class` в ViewSet

### ✅ Задание 4: Тесты
- **6 тестов** написаны в `courses/tests.py`
- **Покрытие**:
  - Создание подписок через разные эндпоинты
  - Проверка отображения статуса подписки
  - CRUD операции с уроками
  - Права доступа для разных ролей пользователей

## 🔧 Технические детали

### API Эндпоинты
| Метод | URL | Описание |
|-------|-----|----------|
| POST | `/api/courses/courses/{id}/subscribe/` | Подписаться/отписаться от курса |
| GET | `/api/courses/courses/{id}/` | Получить курс с полем `is_subscribed` |
| GET | `/api/courses/subscriptions/` | Список подписок текущего пользователя |
| POST | `/api/courses/subscriptions/` | Создать новую подписку |

### Модель Subscription
```python
class Subscription(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['user', 'course']