﻿import stripe
from django.shortcuts import get_object_or_404, render
from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from django.contrib.auth import get_user_model
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import OrderingFilter
from drf_spectacular.utils import extend_schema, OpenApiParameter, OpenApiExample

from config import settings
from courses.services.stripe_service import StripeService
from .models import Payment
from .serializers import UserSerializer, UserRegisterSerializer, PaymentSerializer, PaymentCreateSerializer
from .permissions import IsOwner, IsModerator
import logging

logger = logging.getLogger(__name__)

User = get_user_model()


class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

    def get_serializer_class(self):
        if self.action == 'create':
            return UserRegisterSerializer
        return UserSerializer

    def get_permissions(self):
        """
        Настраиваем права доступа
        """
        if self.action == 'create':
            # Регистрация доступна всем
            permission_classes = [permissions.AllowAny]
        elif self.action in ['update', 'partial_update', 'destroy']:
            # Изменять и удалять можно только свой профиль
            permission_classes = [permissions.IsAuthenticated, IsOwner]
        else:
            # Просматривать профили могут все авторизованные
            permission_classes = [permissions.IsAuthenticated]
        return [permission() for permission in permission_classes]

    @action(detail=False, methods=['get', 'put', 'patch'])
    def me(self, request):
        """
        Получение и обновление профиля текущего пользователя
        """
        if request.method == 'GET':
            serializer = self.get_serializer(request.user)
            return Response(serializer.data)
        elif request.method in ['PUT', 'PATCH']:
            serializer = self.get_serializer(
                request.user,
                data=request.data,
                partial=(request.method == 'PATCH')
            )
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response(serializer.data)
        return None


class PaymentViewSet(viewsets.ModelViewSet):
    queryset = Payment.objects.all()
    serializer_class = PaymentSerializer
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_fields = ['paid_course', 'paid_lesson', 'payment_method', 'status']
    ordering_fields = ['created_at', 'amount']

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy', 'buy', 'my_payments']:
            return [permissions.IsAuthenticated()]
        return [permissions.AllowAny()]

    def get_queryset(self):
        """Фильтрация платежей для текущего пользователя"""
        queryset = super().get_queryset()

        # Если пользователь аутентифицирован, показываем только его платежи
        if self.request.user.is_authenticated and self.action in ['list', 'retrieve']:
            queryset = queryset.filter(user=self.request.user)

        return queryset

    def perform_create(self, serializer):
        """Автоматически устанавливаем пользователя при создании платежа"""
        serializer.save(user=self.request.user)

    @extend_schema(
        summary="Создать платеж через Stripe",
        description="Создает платежную сессию Stripe для оплаты курса или урока",
        request=PaymentCreateSerializer,
        responses={
            201: {
                'description': 'Платёжная сессия создана',
                'examples': {
                    'application/json': {
                        'message': 'Платеж создан',
                        'payment_id': 1,
                        'payment_url': 'https://checkout.stripe.com/pay/cs_test_...',
                        'session_id': 'cs_test_...',
                        'amount': 1999.99,
                        'item_type': 'course',
                        'item_name': 'Название курса'
                    }
                }
            }
        },
        tags=['Платежи']
    )
    @action(detail=False, methods=['post'], url_path='buy')
    def buy(self, request):
        """Создание платежной сессии Stripe"""
        from courses.models import Course, Lesson

        serializer = PaymentCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        try:
            item_type = serializer.validated_data['item_type']
            item_id = serializer.validated_data['item_id']
            user = request.user

            # Получаем оплачиваемый объект
            if item_type == 'course':
                item = get_object_or_404(Course, id=item_id)
                amount = item.price
                item_name = item.title
            else:  # lesson
                item = get_object_or_404(Lesson, id=item_id)
                amount = item.price
                item_name = item.title

            # Проверяем, не куплено ли уже
            existing_payment = Payment.objects.filter(
                user=user,
                paid_course=item if item_type == 'course' else None,
                paid_lesson=item if item_type == 'lesson' else None,
                status='paid'
            ).exists()

            if existing_payment:
                return Response(
                    {'detail': 'Вы уже приобрели этот элемент'},
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Получаем или создаем Stripe ID
            stripe_product_id = item.stripe_product_id
            stripe_price_id = item.stripe_price_id

            # Если нет Stripe ID, создаем их
            if not stripe_product_id or not stripe_price_id:
                logger.info(f"Создаем Stripe продукт для {item_type} '{item_name}'")

                product = StripeService.create_product(
                    name=item_name,
                    description=f"Оплата за {item_type}: {item_name}"
                )

                price = StripeService.create_price(
                    product_id=product.id,
                    amount=float(amount),
                    currency='rub'
                )

                # Сохраняем ID в модель
                item.stripe_product_id = product.id
                item.stripe_price_id = price.id
                item.save()

                stripe_product_id = product.id
                stripe_price_id = price.id
                logger.info(f"Созданы Stripe ID: product={product.id}, price={price.id}")
            else:
                logger.info(f"Используем существующие Stripe ID для {item_type} {item_id}")

            # Используем прямые URL
            success_url = 'http://localhost:8000/api/users/payments/success/?session_id={CHECKOUT_SESSION_ID}'
            cancel_url = 'http://localhost:8000/api/users/payments/cancel/'

            print(f"DEBUG: Success URL: {success_url}")
            print(f"DEBUG: Cancel URL: {cancel_url}")

            # Создаем сессию оплаты
            session = StripeService.create_checkout_session(
                price_id=stripe_price_id,
                user_id=user.id,
                item_id=item.id,
                item_type=item_type,
                success_url=success_url,
                cancel_url=cancel_url
            )

            # Сохраняем платеж в БД
            payment_data = {
                'user': user,
                'amount': amount,
                'currency': 'rub',
                'payment_method': 'stripe',
                'stripe_session_id': session.id,
                'stripe_product_id': stripe_product_id,
                'stripe_price_id': stripe_price_id,
                'payment_url': session.url,
                'status': 'pending'
            }

            if item_type == 'course':
                payment_data['paid_course'] = item
            else:
                payment_data['paid_lesson'] = item

            payment = Payment.objects.create(**payment_data)
            logger.info(f"Создан платеж {payment.id} для пользователя {user.email}")

            return Response({
                'message': 'Платеж создан',
                'payment_id': payment.id,
                'payment_url': session.url,
                'session_id': session.id,
                'amount': float(amount),
                'item_type': item_type,
                'item_name': item_name
            }, status=status.HTTP_201_CREATED)

        except Exception as e:
            logger.error(f"Ошибка создания платежа: {e}")
            logger.exception("Полная трассировка ошибки:")
            return Response(
                {'detail': f'Ошибка при создании платежа: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    @extend_schema(
        summary="Проверить статус платежа",
        description="Проверяет актуальный статус платежа через Stripe API",
        tags=['Платежи']
    )
    @action(detail=True, methods=['get'], url_path='status')
    def payment_status(self, request, pk=None):
        """Проверка статуса платежа через Stripe"""
        payment = self.get_object()

        # Обновляем статус из Stripe
        if payment.stripe_session_id:
            try:
                session = StripeService.retrieve_session(payment.stripe_session_id)

                if session.payment_status == 'paid' and payment.status != 'paid':
                    payment.status = 'paid'
                    payment.stripe_payment_intent_id = session.payment_intent
                    payment.save()
                elif session.payment_status == 'unpaid' and payment.status == 'paid':
                    payment.status = 'pending'
                    payment.save()

            except Exception as e:
                logger.error(f"Ошибка обновления статуса платежа: {e}")

        serializer = self.get_serializer(payment)
        return Response(serializer.data)

    @extend_schema(
        summary="Мои платежи",
        description="Получить список всех платежей текущего пользователя",
        tags=['Платежи']
    )
    @action(detail=False, methods=['get'], url_path='my')
    def my_payments(self, request):
        """Получить все платежи текущего пользователя"""
        payments = Payment.objects.filter(user=request.user).order_by('-created_at')
        serializer = self.get_serializer(payments, many=True)
        return Response(serializer.data)


# ============================================================================
# ОТДЕЛЬНЫЕ VIEW-ФУНКЦИИ ДЛЯ STRIPE РЕДИРЕКТОВ
# ============================================================================

@extend_schema(
    summary="Успешная оплата",
    description="HTML-страница успешного завершения оплаты",
    tags=['Платежи'],
    methods=['GET']
)
@api_view(['GET'])
@permission_classes([AllowAny])
def payment_success(request):
    """Обработка редиректа после успешной оплаты в Stripe"""
    session_id = request.GET.get('session_id')

    # Если session_id не передан (тестовый запрос или ошибка)
    if not session_id:
        return render(request, 'payments/success.html', {
            'title': 'Тестовая страница оплаты',
            'message': 'Страница успешной оплаты готова к работе.',
            'test_mode': True,
            'instruction': 'При реальной оплате Stripe передаст session_id автоматически.'
        })

    try:
        # 1. Получаем платеж из БД
        payment = Payment.objects.get(stripe_session_id=session_id)

        # 2. Проверяем статус в Stripe
        stripe_session = StripeService.retrieve_session(session_id)

        # 3. Получаем название товара
        if payment.paid_course:
            item_name = payment.paid_course.title
            item_type = 'курс'
        elif payment.paid_lesson:
            item_name = payment.paid_lesson.title
            item_type = 'урок'
        else:
            item_name = "Обучение"
            item_type = "материал"

        # 4. Обновляем статус, если оплачено
        if stripe_session.payment_status == 'paid' and payment.status != 'paid':
            payment.status = 'paid'
            payment.stripe_payment_intent_id = stripe_session.payment_intent
            payment.save()

            logger.info(f"Платеж {payment.id} отмечен как оплаченный через редирект")

        # 5. Отображаем страницу успеха
        context = {
            'title': 'Оплата успешно завершена!',
            'message': f'Вы успешно оплатили {item_type}:',
            'item_name': item_name,
            'item_type': item_type,
            'amount': payment.amount,
            'currency': payment.currency,
            'payment_id': payment.id,
            'payment_status': payment.status,
            'stripe_status': stripe_session.payment_status,
            'customer_email': stripe_session.customer_details.email if hasattr(stripe_session.customer_details,
                                                                               'email') else None,
            'real_payment': True
        }

        return render(request, 'payments/success.html', context)

    except Payment.DoesNotExist:
        logger.warning(f"Платеж с session_id {session_id} не найден в БД")
        return render(request, 'payments/success.html', {
            'title': 'Информация о платеже',
            'message': 'Данные о платеже обрабатываются.',
            'session_id': session_id,
            'note': 'Платеж может появиться в системе через несколько секунд.'
        })

    except Exception as e:
        logger.error(f"Ошибка обработки успешной оплаты: {e}")
        return render(request, 'payments/error.html', {
            'title': 'Ошибка обработки',
            'message': 'Произошла ошибка при обработке платежа.',
            'error_details': str(e)
        })


@extend_schema(
    summary="Отмена оплаты",
    description="HTML-страница отмены оплаты",
    tags=['Платежи'],
    methods=['GET']
)
@api_view(['GET'])
@permission_classes([AllowAny])
def payment_cancel(request):
    """Обработка редиректа при отмене оплаты в Stripe"""
    session_id = request.GET.get('session_id')

    context = {
        'title': 'Оплата отменена',
        'message': 'Вы отменили процесс оплаты.',
        'has_payment': False
    }

    if session_id:
        try:
            payment = Payment.objects.get(stripe_session_id=session_id)
            payment.status = 'cancelled'
            payment.save()
            logger.info(f"Платеж {payment.id} отменен пользователем")

            if payment.paid_course:
                item_name = payment.paid_course.title
            elif payment.paid_lesson:
                item_name = payment.paid_lesson.title
            else:
                item_name = "товар"

            context.update({
                'has_payment': True,
                'item_name': item_name,
                'amount': payment.amount,
                'payment_id': payment.id
            })
        except Payment.DoesNotExist:
            pass

    return render(request, 'payments/cancel.html', context)


@extend_schema(
    summary="Вебхук Stripe",
    description="""Эндпоинт для получения событий от Stripe.

    Настройте в Stripe Dashboard вебхук на этот URL.
    Поддерживаемые события:
    - checkout.session.completed
    - checkout.session.expired  
    - payment_intent.succeeded
    - payment_intent.payment_failed

    Требуемые заголовки:
    - Stripe-Signature: подпись вебхука
    """,
    tags=['Платежи'],
    methods=['POST'],
    request={
        'application/json': {
            'example': {
                'id': 'evt_1O7I2nFz6Z6q4r6Xw4pQ4pQ4',
                'type': 'checkout.session.completed',
                'data': {
                    'object': {
                        'id': 'cs_test_...',
                        'payment_status': 'paid'
                    }
                }
            }
        }
    },
    responses={
        200: {
            'description': 'Вебхук обработан успешно',
            'examples': {
                'application/json': {
                    'status': 'success',
                    'event': 'checkout.session.completed'
                }
            }
        },
        400: {
            'description': 'Ошибка валидации',
            'examples': {
                'application/json': {
                    'error': 'Неверная подпись вебхука'
                }
            }
        }
    }
)
@api_view(['POST'])
@permission_classes([AllowAny])
def stripe_webhook(request):
    """
    Обработчик вебхуков от Stripe.
    Настройте вебхук в Stripe Dashboard на этот URL.
    """
    payload = request.body
    sig_header = request.headers.get('Stripe-Signature')
    webhook_secret = getattr(settings, 'STRIPE_WEBHOOK_SECRET', '')

    if not webhook_secret:
        logger.warning("STRIPE_WEBHOOK_SECRET не настроен")
        return Response({'error': 'Webhook секрет не настроен'}, status=400)

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, webhook_secret
        )
    except ValueError as e:
        # Invalid payload
        logger.error(f"Неверный payload вебхука: {e}")
        return Response({'error': str(e)}, status=400)
    except stripe.error.SignatureVerificationError as e:
        # Invalid signature
        logger.error(f"Неверная подпись вебхука: {e}")
        return Response({'error': str(e)}, status=400)

    # Обработка событий
    event_type = event['type']
    logger.info(f"Получено событие Stripe: {event_type}")

    if event_type == 'checkout.session.completed':
        session = event['data']['object']

        try:
            payment = Payment.objects.get(stripe_session_id=session['id'])

            if session['payment_status'] == 'paid' and payment.status != 'paid':
                payment.status = 'paid'
                payment.stripe_payment_intent_id = session.get('payment_intent')
                payment.save()

                logger.info(f"Платеж {payment.id} отмечен как оплаченный через вебхук")

                # Здесь можно добавить дополнительную логику:
                # - Отправить email пользователю
                # - Активировать доступ к курсу
                # - Обновить статистику

        except Payment.DoesNotExist:
            logger.error(f"Платеж с session_id {session['id']} не найден")

    elif event_type == 'checkout.session.expired':
        session = event['data']['object']

        try:
            payment = Payment.objects.get(stripe_session_id=session['id'])
            payment.status = 'cancelled'
            payment.save()
            logger.info(f"Платеж {payment.id} истек")
        except Payment.DoesNotExist:
            pass

    elif event_type == 'payment_intent.succeeded':
        # Дополнительная обработка успешного платежа
        payment_intent = event['data']['object']
        logger.info(f"PaymentIntent успешен: {payment_intent['id']}")

    elif event_type == 'payment_intent.payment_failed':
        # Обработка неудачного платежа
        payment_intent = event['data']['object']
        logger.warning(f"PaymentIntent не удался: {payment_intent['id']}")

    return Response({'status': 'success', 'event': event_type})


@extend_schema(
    summary="Тестовый эндпоинт для проверки кодировки",
    description="Проверяет корректность работы UTF-8 кодировки в Django DRF",
    tags=['Тестирование']
)
@api_view(['GET'])
@permission_classes([AllowAny])
def test_encoding(request):
    """Тестовый эндпоинт для проверки кодировки"""
    return Response({
        "message": "Тест русских символов",
        "data": {
            "city": "Москва",
            "name": "Иван Петров",
            "description": "Тестирование кодировки UTF-8 в Django DRF"
        },
        "status": "success",
        "test": "Привет мир! Санкт-Петербург, Казань, Екатеринбург"
    })

"""
СТАРЫЕ ФУНКЦИИ ЗАКОММЕНТИРОВАНЫ - ИСПОЛЬЗУЙТЕ final_fix.py
"""