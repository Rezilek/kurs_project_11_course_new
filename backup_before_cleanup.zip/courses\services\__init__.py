def create_stripe_product():
    return None


def create_stripe_price():
    return None


def create_stripe_checkout_session():
    return None


def get_stripe_session_status():
    return None