#!/usr/bin/env python
"""
Скрипт для ожидания базы данных внутри Docker контейнера
Используется в docker-compose command
"""
import os
import sys
import time
import socket


def wait_for_service(host, port, timeout=60):
    """
    Ожидает доступности TCP сервиса
    """
    start_time = time.time()
    attempt = 0

    print(f"Waiting for {host}:{port}...")

    while time.time() - start_time < timeout:
        attempt += 1
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            result = sock.connect_ex((host, int(port)))
            sock.close()

            if result == 0:
                print(f"✓ Service {host}:{port} is available (attempt {attempt})")
                return True
            else:
                print(f"  Attempt {attempt}: Service {host}:{port} not ready")

        except Exception as e:
            print(f"  Attempt {attempt}: Error connecting to {host}:{port} - {e}")

        time.sleep(2)

    print(f"✗ Timeout waiting for {host}:{port} after {timeout} seconds")
    return False


def wait_for_postgres():
    """
    Ожидает доступности PostgreSQL
    """
    db_host = os.getenv('POSTGRES_HOST', 'db')
    db_port = os.getenv('POSTGRES_PORT', '5432')

    print(f"Checking PostgreSQL at {db_host}:{db_port}")

    # Сначала проверяем доступность хоста через TCP
    if not wait_for_service(db_host, db_port, timeout=60):
        return False

    # Затем проверяем подключение к базе данных
    print("Testing database connection...")

    # Даем дополнительные 30 секунд для полной инициализации PostgreSQL
    additional_wait = 30
    print(f"Giving PostgreSQL {additional_wait} seconds to fully initialize...")
    time.sleep(additional_wait)

    return True


if __name__ == '__main__':
    try:
        if wait_for_postgres():
            print("Database is ready!")
            sys.exit(0)
        else:
            print("Failed to connect to database")
            sys.exit(1)
    except KeyboardInterrupt:
        print("Interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)
        